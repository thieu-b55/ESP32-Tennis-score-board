## Animated GIF Decoding Example

### Prerequisites
1. The excellent 'AnimatedGIF' library by Larry Bank needs to be installed: https://github.com/bitbank2/AnimatedGIF

This is available via the Arduino Library manager, or can be placed in the 'libs' directory with PlatformIO.

2. The files in the 'data' folder are written to the ESP32's SPIFFS file system.


## Credits

https://github.com/bitbank2/AnimatedGIF
