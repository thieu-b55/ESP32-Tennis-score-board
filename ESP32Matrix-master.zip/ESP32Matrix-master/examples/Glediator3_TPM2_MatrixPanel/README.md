# Glediator3_TPM2_MatrixPanel
An example of controlling an LED Matrix panel using desktop software via. the serial TPM2 protocol.

This is very experimental and might not work. Please note the frame rate on a 64x32 panel will be low (about 12fps) due to the limitation of  Serial port throughput!

# How to use
* Install the TPM2 library: https://github.com/rstephan/TPM2
* Then get Glediator3 running on your computer, and connect to the LED Matrix device via. Serial Port.

Refer to: https://github.com/mrfaptastic/Glediator3
